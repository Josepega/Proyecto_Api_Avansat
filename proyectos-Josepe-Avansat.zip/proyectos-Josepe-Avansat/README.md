# proyectos
repositorio para proyectos de clase

DESCRIPCIÓN

APP: Gestión de clientes AVANSAT
Desarrollo: Josepe Gallicchio

Descripción: Aplicacion para gestión de datos de clientes del servicipo técnico de AVANSAT servicio de asistencia técnica.

FASES

- Fase 1: Registro de CLIENTES.
Se desarrola la gestión y almacenado de datos personales de los clientes nuevos y antiguos en una base de datos usando un aplicativo web.

- FAse 2: Registro de SERVICIOS
Se desarrola la gestión y almacenado de datos de los SERVICIOS nuevos y antiguos en una base de datos usando un aplicativo web.

- Fase 3: Facturación
 Facturación de los SERVICIOS prestados a los CLIENTES utilizando las bases de datos CLIENTES / SERVICIOS / usando el aplicativo web.

 - FAse 4: Registro de REPUESTOS
Se desarrola la gestión y almacenado de STOCK de los REPUESTOS nuevos y antiguos en una base de datos usando un aplicativo web.


RECURSOS

Búsqueda de población en altas de CLIENTES. API deInstituto de Estadística de Cataluña URL: https://www.idescat.cat/dev/api/pob/?lang=es

Resumen
URI base	https://api.idescat.cat/pob/v1/{operación}.{formato}[?parámetros]
Método HTTP	GET
Formatos de la respuesta	xml, json, php, txt
Versión	1.00 (20/05/2010)
Atajos	Petición, Respuesta
Operaciones	cerca, sug