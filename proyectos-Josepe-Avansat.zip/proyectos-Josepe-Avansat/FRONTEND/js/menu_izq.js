const botonToggle = document.querySelector('.toggle_boton');

botonToggle.addEventListener('click', () => {
    document.getElementById('izq').classList.toggle('active');

    
})
